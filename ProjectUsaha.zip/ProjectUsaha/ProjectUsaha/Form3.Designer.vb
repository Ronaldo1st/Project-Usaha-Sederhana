﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormGaji
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TxtTotal = New System.Windows.Forms.TextBox()
        Me.CmbJabatan = New System.Windows.Forms.ComboBox()
        Me.CmbGOL = New System.Windows.Forms.ComboBox()
        Me.CmbNIK = New System.Windows.Forms.ComboBox()
        Me.TxtTunj = New System.Windows.Forms.TextBox()
        Me.TxtGaji = New System.Windows.Forms.TextBox()
        Me.TxtNama = New System.Windows.Forms.TextBox()
        Me.CmdProses = New System.Windows.Forms.Button()
        Me.CmdHapus = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(474, 345)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(77, 27)
        Me.Button3.TabIndex = 35
        Me.Button3.Text = "Exit"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TxtTotal
        '
        Me.TxtTotal.Location = New System.Drawing.Point(107, 325)
        Me.TxtTotal.Name = "TxtTotal"
        Me.TxtTotal.Size = New System.Drawing.Size(205, 20)
        Me.TxtTotal.TabIndex = 34
        '
        'CmbJabatan
        '
        Me.CmbJabatan.FormattingEnabled = True
        Me.CmbJabatan.Location = New System.Drawing.Point(107, 202)
        Me.CmbJabatan.Name = "CmbJabatan"
        Me.CmbJabatan.Size = New System.Drawing.Size(186, 21)
        Me.CmbJabatan.TabIndex = 33
        '
        'CmbGOL
        '
        Me.CmbGOL.FormattingEnabled = True
        Me.CmbGOL.Location = New System.Drawing.Point(107, 130)
        Me.CmbGOL.Name = "CmbGOL"
        Me.CmbGOL.Size = New System.Drawing.Size(56, 21)
        Me.CmbGOL.TabIndex = 32
        '
        'CmbNIK
        '
        Me.CmbNIK.FormattingEnabled = True
        Me.CmbNIK.Location = New System.Drawing.Point(107, 49)
        Me.CmbNIK.Name = "CmbNIK"
        Me.CmbNIK.Size = New System.Drawing.Size(152, 21)
        Me.CmbNIK.TabIndex = 31
        '
        'TxtTunj
        '
        Me.TxtTunj.Location = New System.Drawing.Point(107, 242)
        Me.TxtTunj.Name = "TxtTunj"
        Me.TxtTunj.Size = New System.Drawing.Size(133, 20)
        Me.TxtTunj.TabIndex = 30
        '
        'TxtGaji
        '
        Me.TxtGaji.Location = New System.Drawing.Point(107, 168)
        Me.TxtGaji.Name = "TxtGaji"
        Me.TxtGaji.Size = New System.Drawing.Size(133, 20)
        Me.TxtGaji.TabIndex = 29
        '
        'TxtNama
        '
        Me.TxtNama.Location = New System.Drawing.Point(107, 90)
        Me.TxtNama.Name = "TxtNama"
        Me.TxtNama.Size = New System.Drawing.Size(198, 20)
        Me.TxtNama.TabIndex = 28
        '
        'CmdProses
        '
        Me.CmdProses.Location = New System.Drawing.Point(241, 282)
        Me.CmdProses.Name = "CmdProses"
        Me.CmdProses.Size = New System.Drawing.Size(64, 21)
        Me.CmdProses.TabIndex = 27
        Me.CmdProses.Text = "Proses"
        Me.CmdProses.UseVisualStyleBackColor = True
        '
        'CmdHapus
        '
        Me.CmdHapus.Location = New System.Drawing.Point(107, 282)
        Me.CmdHapus.Name = "CmdHapus"
        Me.CmdHapus.Size = New System.Drawing.Size(71, 21)
        Me.CmdHapus.TabIndex = 26
        Me.CmdHapus.Text = "Delete"
        Me.CmdHapus.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(14, 332)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(68, 13)
        Me.Label8.TabIndex = 25
        Me.Label8.Text = "TOTAL GAJI"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 249)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 13)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "TUNJANGAN"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 210)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "JABATAN"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(14, 175)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 13)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "GAJI"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 138)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "GOL DARAH"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 97)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 20
        Me.Label3.Text = "NAMA"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(25, 13)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "NIK"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Javanese Text", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(238, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(168, 29)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Program Gaji Karyawan"
        '
        'FormGaji
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ProjectUsaha.My.Resources.Resources._41_417664_shiny_modern_background_wallpaper_in_only_two_colors
        Me.ClientSize = New System.Drawing.Size(563, 384)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.TxtTotal)
        Me.Controls.Add(Me.CmbJabatan)
        Me.Controls.Add(Me.CmbGOL)
        Me.Controls.Add(Me.CmbNIK)
        Me.Controls.Add(Me.TxtTunj)
        Me.Controls.Add(Me.TxtGaji)
        Me.Controls.Add(Me.TxtNama)
        Me.Controls.Add(Me.CmdProses)
        Me.Controls.Add(Me.CmdHapus)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormGaji"
        Me.Text = "Form Gaji Karyawan"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button3 As Button
    Friend WithEvents TxtTotal As TextBox
    Friend WithEvents CmbJabatan As ComboBox
    Friend WithEvents CmbGOL As ComboBox
    Friend WithEvents CmbNIK As ComboBox
    Friend WithEvents TxtTunj As TextBox
    Friend WithEvents TxtGaji As TextBox
    Friend WithEvents TxtNama As TextBox
    Friend WithEvents CmdProses As Button
    Friend WithEvents CmdHapus As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
