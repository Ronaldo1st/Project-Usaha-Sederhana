﻿Public Class FormGaji
    Private Sub CmbNIK_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbNIK.SelectedIndexChanged
        Select Case CmbNIK.Text
            Case "001"
                TxtNama.Text = "Dodoy"
            Case "002"
                TxtNama.Text = "Ronel"
            Case "003"
                TxtNama.Text = "Devud"
            Case Else
                TxtNama.Text = ""

        End Select
    End Sub

    Private Sub CmbGOL_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbGOL.SelectedIndexChanged
        Select Case CmbGOL.Text
            Case "A"
                TxtGaji.Text = 2500000
            Case "B"
                TxtGaji.Text = 3000000
            Case "AB"
                TxtGaji.Text = 3500000
            Case "O"
                TxtGaji.Text = 4000000
            Case Else
                TxtGaji.Text = ""
        End Select

    End Sub

    Private Sub CmbJabatan_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CmbJabatan.SelectedIndexChanged
        Select Case CmbJabatan.Text
            Case "HRD"
                TxtTunj.Text = 2000000
            Case "OPERATOR"
                TxtTunj.Text = 1000000
            Case Else
                TxtTunj.Text = ""
        End Select
    End Sub

    Private Sub CmdHapus_Click(sender As Object, e As EventArgs) Handles CmdHapus.Click
        CmbNIK.Text = ""
        TxtNama.Text = ""
        CmbGOL.Text = ""
        CmbJabatan.Text = ""
        TxtGaji.Text = ""
        TxtTunj.Text = ""
        TxtTotal.Text = ""
    End Sub

    Private Sub CmdProses_Click(sender As Object, e As EventArgs) Handles CmdProses.Click
        TxtTotal.Text = Val(TxtGaji.Text) + Val(TxtTunj.Text)
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CmbNIK.Items.Add("001")
        CmbNIK.Items.Add("002")
        CmbNIK.Items.Add("003")

        CmbGOL.Items.Add("A")
        CmbGOL.Items.Add("B")
        CmbGOL.Items.Add("AB")
        CmbGOL.Items.Add("O")
        CmbGOL.Items.Add("ETC")

        CmbJabatan.Items.Add("HRD")
        CmbJabatan.Items.Add("OPERATOR")

        CmdHapus_Click(sender, e)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub
End Class