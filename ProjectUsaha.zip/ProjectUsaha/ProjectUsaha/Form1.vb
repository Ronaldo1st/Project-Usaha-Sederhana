﻿Public Class Form1
    Private Sub GajiKaryawanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GajiKaryawanToolStripMenuItem.Click
        FormGaji.Show()
    End Sub

    Private Sub MakananToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MakananToolStripMenuItem.Click
        FormMakanan.Show()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
